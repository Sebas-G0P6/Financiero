from . import medio_magnetico
from . import medio_magnetico_line
from . import medio_magnetico_validations