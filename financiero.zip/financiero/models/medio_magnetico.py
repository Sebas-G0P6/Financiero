from odoo import fields, models, api
from odoo.exceptions import ValidationError
import base64

from ..services.txt_builder import TXTBuilder

class MedioMagnetico(models.Model):
    _name = 'medio.magnetico'
    _description = 'Medio Magnético SIESA'
    _order = 'anio DESC, formato DESC'

    # Campos básicos
    name = fields.Char(
        string='Nombre',
        compute='_compute_name',
        store=True,
        help='Generado automáticamente: AÑO-FORMATO'
    )
    anio = fields.Char(
        string='Año',
        required=True,
        size=4,
        help='Año del medio magnético (AAAA)'
    )
    formato = fields.Char(
        string='Formato',
        required=True,
        size=10,
        help='Código de formato SIESA'
    )
    concepto = fields.Char(
        string='Concepto',
        size=10,
        help='Concepto o descripción del movimiento'
    )

    # Archivos
    archivo_datos = fields.Binary(
        string='Archivo Datos (Excel)',
        help='Excel con los terceros a importar'
    )
    archivo_datos_name = fields.Char(
        string='Nombre Archivo Datos'
    )
    archivo_txt = fields.Binary(
        string='Archivo TXT Generado',
        readonly=True,
        help='Archivo TXT generado en formato SIESA'
    )
    archivo_txt_name = fields.Char(
        string='Nombre Archivo TXT',
        readonly=True,
        default='medio_magnetico.txt'
    )
    archivo_hash = fields.Char(
        string='Hash Archivo',
        readonly=False,
        help='Hash MD5 del archivo importado para evitar reprocesos'
    )

    errores_importacion = fields.Text(
        string='Errores de Importación',
        readonly=True,
    )

    # Estado
    estado = fields.Selection(
        [('borrador', 'Borrador'), ('generado', 'Generado')],
        string='Estado',
        default='borrador',
        help='Estado del medio magnético'
    )

    # Líneas de datos
    line_ids = fields.One2many(
        'medio.magnetico.line',
        'medio_id',
        string='Líneas de Datos',
        help='Registros de datos para el archivo magnético'
    )

    @api.depends('anio', 'formato')
    def _compute_name(self):
        for record in self:
            record.name = f"{record.anio}-{record.formato}" if record.anio and record.formato else 'Sin nombre'

    @api.constrains('anio')
    def _check_anio(self):
        for record in self:
            if record.anio and (not record.anio.isdigit() or len(record.anio) != 4):
                raise ValidationError('El año debe ser numérico de 4 dígitos (AAAA)')

    def action_importar_excel(self):
        self.ensure_one()

        if not self.archivo_datos:
            raise ValidationError('Debe adjuntar un archivo Excel antes de importar.')

        archivo_binario = bytes(base64.b64decode(self.archivo_datos))
        nombre_archivo = (self.archivo_datos_name or '').strip().lower()
        filas_raw = self._leer_filas_excel(archivo_binario, nombre_archivo)
        errores, registros_validos = self._validar_filas(filas_raw)

        if errores:
            self.write({
                'archivo_datos': False,
                'archivo_datos_name': False,
                'archivo_hash': False,
                'errores_importacion': "\n".join(errores),
            })
            return {'type': 'ir.actions.client', 'tag': 'reload'}

        self.line_ids.unlink()
        self.archivo_txt = False
        self.estado = 'borrador'
        self.errores_importacion = False

        Line = self.env['medio.magnetico.line']
        for reg in registros_validos:
            vals = {'medio_id': self.id, 'tercero': reg['tercero']}
            for i, v in enumerate(reg['valores'], start=1):
                vals[f'valor{i}'] = v
            Line.create(vals)

        self.write({
            'archivo_datos': False,
            'archivo_datos_name': False,
            'archivo_hash': False,
            'errores_importacion': False,
        })

        return {
            'type': 'ir.actions.act_window',
            'res_model': self._name,
            'res_id': self.id,
            'view_mode': 'form',
            'target': 'current',
        }

    def action_generar_txt(self):
        self.ensure_one()

        if not self.line_ids:
            raise ValidationError('No hay líneas de datos para generar el archivo')

        try:
            registros = []
            for line in self.line_ids:
                registro = {
                    'AÑO': self.anio,
                    'FORMATO': self.formato,
                    'CONCEPTO': self.concepto or '',
                    'TERCERO': line.tercero,
                    'MANDANTE': line.mandante or '',
                    'FIDEICOMISO': line.fideicomiso or '',
                    'TIPO_ENTIDAD': 0,
                    'TARIFA': 0,
                    'PERIODO': 0,
                }
                for i in range(1, 31):
                    campo_name = f'valor{i}'
                    if hasattr(line, campo_name):
                        registro[f'VALOR_{i}'] = getattr(line, campo_name, 0) or 0
                registros.append(registro)

            contenido_txt = TXTBuilder.generar_archivo_txt(registros, TXTBuilder.CAMPO_SPECS)
            self.archivo_txt = base64.b64encode(contenido_txt.encode('utf-8'))
            self.estado = 'generado'

            return {'type': 'ir.actions.client', 'tag': 'reload'}

        except Exception as e:
            self.write({'archivo_datos': False, 'archivo_datos_name': False})
            raise ValidationError(f'Error inesperado al generar archivo TXT: {str(e)}')

    def action_descargar_txt(self):
        self.ensure_one()

        if not self.archivo_txt:
            raise ValidationError('No hay archivo TXT generado')

        return {
            'type': 'ir.actions.act_url',
            'url': (
                f'/web/content?model={self._name}'
                f'&id={self.id}'
                f'&field=archivo_txt'
                f'&filename_field=archivo_txt_name'
                f'&download=true'
            ),
            'target': 'self',
        }

    def action_limpiar(self):
        self.ensure_one()
        self.archivo_txt = False
        self.estado = 'borrador'