from odoo import models
from odoo.exceptions import ValidationError

class MedioMagneticoValidations(models.Model):
    _inherit = 'medio.magnetico'

    def _leer_filas_excel(self, archivo_binario, nombre_archivo):
        import io

        if nombre_archivo.endswith('.xlsx'):
            import openpyxl
            wb = openpyxl.load_workbook(io.BytesIO(archivo_binario), data_only=True)
            ws = wb.active

            for row in ws.iter_rows(min_row=2, values_only=True):
                print("EXCEL:", row)

            return [
                (idx, list(row))
                for idx, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2)
            ]

        elif nombre_archivo.endswith('.xls'):
            import xlrd
            wb = xlrd.open_workbook(file_contents=archivo_binario)
            ws = wb.sheet_by_index(0)

            return [
                (i + 1, ws.row_values(i))
                for i in range(1, ws.nrows)
            ]

        else:
            raise ValidationError('Formato no soportado. Use .xls o .xlsx')

    def _col_letra(self, index_base0):
        letras = ''
        n = index_base0 + 1

        while n > 0:
            n, rem = divmod(n - 1, 26)
            letras = chr(65 + rem) + letras

        return letras

    def _validar_filas(self, filas_raw):
        errores = []
        registros_validos = []
        cedulas_vistas = {}

        for idx_fila, row in filas_raw:
            print("ROW:", row)

            if not row or all(v in (None, '', 0) for v in row):
                continue

            valor_col_a = row[0] if row else None

            if isinstance(valor_col_a, float) and valor_col_a == int(valor_col_a):
                tercero = str(int(valor_col_a))
            else:
                tercero = str(valor_col_a).strip() if valor_col_a not in (None, '') else ''

            if not tercero:
                errores.append(
                    f"Fila {idx_fila}, columna A: el campo Tercero (NIT/CC) está vacío."
                )
                continue

            # Validar cédulas repetidas
            if tercero in cedulas_vistas:

                fila_original = cedulas_vistas[tercero]

                errores.append(
                    f"Fila {idx_fila}, columna A: "
                    f"cédula repetida ({tercero}). "
                    f"Ya existe en la fila {fila_original}."
                )

                continue

            cedulas_vistas[tercero] = idx_fila

            valores = []
            fila_con_error = False

            for col_i in range(1, 31):
                letra = self._col_letra(col_i)

                if col_i >= len(row):
                    valores.append(0.0)
                    continue

                raw = row[col_i]

                if raw in (None, ''):
                    valores.append(0.0)
                    continue

                try:
                    valor = float(raw)
                except (ValueError, TypeError):
                    errores.append(
                        f"Fila {idx_fila}, columna {letra}: no numérico → {raw}"
                    )
                    fila_con_error = True
                    continue

                if valor < 0:
                    valor_mostrar = (
                        str(int(valor))
                        if float(valor).is_integer()
                        else str(valor)
                    )
                    errores.append(
                        f"Fila {idx_fila}, columna {letra}: negativo → {valor_mostrar}"
                    )
                    fila_con_error = True
                    continue

                valores.append(valor)

            if not fila_con_error:
                registros_validos.append({
                    'tercero': tercero,
                    'valores': valores
                })

        return errores, registros_validos
